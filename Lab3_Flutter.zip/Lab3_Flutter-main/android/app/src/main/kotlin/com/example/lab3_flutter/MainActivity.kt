package com.example.lab3_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
